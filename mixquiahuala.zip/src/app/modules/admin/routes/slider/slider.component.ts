import { Component, OnInit } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { AngularFireStorage } from '@angular/fire/storage';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Editor, Toolbar } from 'ngx-editor';
import { Observable } from 'rxjs';
import { finalize, map } from 'rxjs/operators';
import { FirebasestorageService } from 'src/app/core/services/firebasestorage.service';
import { LoadingService } from 'src/app/core/services/loading.service';
declare var $: any;
@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.css'],
})
export class SliderComponent implements OnInit {
  public urlFilePublic: string = '';
  constructor(
    private db: AngularFirestore,
    private storage: AngularFireStorage,
    private loadService: LoadingService
  ) {}

  convocatorias$ = new Observable<any>();

  frmNewSlider = new FormGroup({
    title: new FormControl(
      {
        value: '',
        disabled: false,
      },
      Validators.required
    ),
    image: new FormControl({ value: '', disabled: false }, Validators.required),
    description: new FormControl(
      { value: '', disabled: false },
      Validators.required
    ),
    link: new FormControl(''),
  });

  async newSlider() {
    if (!this.frmNewSlider.valid) {
      alert('todos los datos son requeridos');
    } else {
      console.log(this.frmNewSlider.value);

      $('#modSlides').modal('hide');

      // let extension = archivo?.value.split('.').pop();
      let newConvocatoria = this.db.collection('sliders').doc().ref;
      // let filename = `${newConvocatoria.id}.${extension}`;
      let data = this.frmNewSlider.value;
      data.urlImage = this.urlFilePublic;
      newConvocatoria.set(data);
    }
  }

  ngOnInit(): void {
    const doc = this.db.collection('sliders');

    this.convocatorias$.pipe(map((c) => console.log(c)));
    this.convocatorias$ = doc.valueChanges();
  }

  ngOnDestroy(): void {}

  public cambioArchivo(event: any) {
    this.loadService.loading$.emit({
      active: true,
      text: 'Cargando imagen ...',
    });
    var n = Date.now();
    const file = event.target.files[0];
    const filePath = `galeria/${n}`;
    const fileRef = this.storage.ref(filePath);
    const task = this.storage.upload(`galeria/${n}`, file);
    task
      .snapshotChanges()
      .pipe(
        finalize(() => {
          const downloadURL = fileRef.getDownloadURL();
          downloadURL.subscribe((url: any) => {
            if (url) {
              this.urlFilePublic = url;
              this.loadService.loading$.emit({ active: false });
            }
            console.log(this.urlFilePublic);
          });
        })
      )
      .subscribe((url: any) => {
        if (url) {
          console.log(url);
        }
      });
  }
}
