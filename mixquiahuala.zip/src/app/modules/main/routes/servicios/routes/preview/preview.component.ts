import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.css'],
})
export class PreviewComponent implements OnInit {
  serviceID: any = null;
  bodyHtml: string = '<p> <h1>Cuerpo del servicio</h1> </p>';
  constructor(private route: ActivatedRoute, private router: Router) {}

  ngOnInit(): void {
    const routeParams = this.route.snapshot.paramMap;
    this.serviceID = routeParams.get('serviceID');
    if (!this.serviceID) {
      this.router.navigate(['/servicios']);
    }
  }
}
