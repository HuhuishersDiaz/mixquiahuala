import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ServiciosRoutingModule } from './servicios-routing.module';
import { AllComponent } from './routes/all/all.component';
import { PreviewComponent } from './routes/preview/preview.component';

@NgModule({
  declarations: [AllComponent, PreviewComponent],
  imports: [CommonModule, ServiciosRoutingModule],
})
export class ServiciosModule {}
