export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyDnnbbDW92xf-YKiJh8popkH9bfQC4bCJM',
    authDomain: 'ng-sis-pre.firebaseapp.com',
    databaseURL: 'https://ng-sis-pre-default-rtdb.firebaseio.com',
    projectId: 'ng-sis-pre',
    storageBucket: 'ng-sis-pre.appspot.com',
    messagingSenderId: '977176905811',
    appId: '1:977176905811:web:c3da53e3cba343b7451ea6',
  },
};
